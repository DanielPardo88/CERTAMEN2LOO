﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CERTAMEN1DANIELPARDO
{
    class DEPARTAMENTO: Entity
    {
        
        public string nombredepartamento { get; set; }

        public DEPARTAMENTO(int id, string nombredepartamento)
        {
            this.id = id;
            this.nombredepartamento = nombredepartamento;
        }

        public DEPARTAMENTO()
        {
        }
    }
}
