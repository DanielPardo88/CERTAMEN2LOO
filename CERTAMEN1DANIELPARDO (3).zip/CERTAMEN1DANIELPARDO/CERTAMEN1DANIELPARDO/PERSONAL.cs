﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CERTAMEN1DANIELPARDO
{
    class PERSONAL:Entity
    {
        
        public int rut { get; set; }

        public int telefono { get; set; }

        public string domicilio { get; set; }

        public List<CARGO> cargo{ get; set; }

        public List<JEFEDIRECTO> jefedirecto { get; set; }

        public List<DEPARTAMENTO> departamento { get; set; }

        public PERSONAL(int id, string nombre, int rut, int telefono, string domicilio)
        {
            this.id = id;
            this.nombre = nombre;
            this.rut = rut;
            this.telefono = telefono;
            this.domicilio = domicilio;
            cargo = new List<CARGO>();
            jefedirecto = new List<JEFEDIRECTO>();
            departamento = new List<DEPARTAMENTO>();

        }

        public PERSONAL()
        {
            cargo = new List<CARGO>();

            jefedirecto = new List<JEFEDIRECTO>();

            departamento = new List<DEPARTAMENTO>();
        }

        void agregarCargo(CARGO cargo)
        {
            this.cargo.Add(cargo);
        }

        void agregarDepartamento (DEPARTAMENTO departamento)
        {
            this.departamento.Add(departamento);
        }

        void agregarJefedirecto(JEFEDIRECTO jefedirecto)
        {
            this.jefedirecto.Add(jefedirecto);
        }
    }
}
