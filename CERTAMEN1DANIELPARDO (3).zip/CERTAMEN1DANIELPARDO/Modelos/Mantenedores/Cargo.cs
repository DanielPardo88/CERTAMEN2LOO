﻿using CERTAMEN1DANIELPARDO;
using DATOS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Mantenedores
{
    public class Cargo : IDataEntity
    {
        public int id_cargo { get; set; }
        public string nombre_cargo { get; set; }
        public data Data { get; set; }
        public List<Parametros> Parametros { get; set; }

        public Cargo()
        {
            Data = new data();
            Parametros = new List<Parametros>();
        }
    }
}
