﻿namespace API.Controllers
{
    internal class Cargo
    {
        internal int id_cargo;
        internal string nombre_cargo;
    }
}