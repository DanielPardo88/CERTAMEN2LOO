﻿using System;
using System.Reflection;
using API.Helper;
using Microsoft.AspNetCore.Mvc;
using Modelos.Mantenedores;
using Negocio.Mantenedores;
using static API.Datos;

namespace API.Controllers
{
    [ApiController]
    public class JefeController : ControllerBase
    {
        JefeBL jefeBL = new JefeBL();
        JefeBL jefe = new JefeBL();
        ErrorResponse error;

        [HttpPost]
        [Route("v1/jefe/Create")]
        public ActionResult Create(JefeDTO o)
        {
            try
            {
                jefe.rut_jefe = o.rut_jefe;
                jefe.nombre_jefe = o.nombre_jefe;
                jefe.apellido_jefe = o.apellido_jefe;

                return Ok(jefeBL.Create(jefe));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/jefe/Get")]
        public ActionResult Get()
        {
            try
            {
                return Ok(convertList(jefeBL.Get(jefe)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpPost]
        [Route("v1/jefe/GetQuery")]
        public ActionResult GetQuery(string nombre, string apellido)
        {
            try
            {
                jefe.nombre_jefe = nombre;
                jefe.apellido_jefe = apellido;
                return Ok(convertList(jefeBL.GetQuery(jefe)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/jefe/GetById")]
        public ActionResult GetById(int id)
        {
            try
            {
                jefe.rut_jefe = id;
                jefe = jefeBL.GetById(jefe);
                if (jefe != null)
                    return Ok(convert(jefe));
                else
                    return StatusCode(404, jefe);
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }
        [HttpPut]
        [Route("v1/jefe/Update")]
        public ActionResult Update(JefeDTO o)
        {
            try
            {
                jefe.rut_jefe = o.rut_jefe;
                jefe.nombre_jefe = o.nombre_jefe;
                jefe.apellido_jefe = o.apellido_jefe;

                return Ok(jefeBL.Update(jefe));


            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpDelete]
        [Route("v1/jefe/Delete")]
        public ActionResult Delete(int id)
        {
            try
            {
                jefe.rut_jefe = id;
                return Ok(jefeBL.Delete(jefe));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        private List<JefeDTO> convertList(List<Jefe> lista)
        {
            List<JefeDTO> list = new List<JefeDTO>();
            foreach (var item in lista)
            {
                JefeDTO el = new JefeDTO(item.rut_jefe, item.nombre_jefe, item.apellido_jefe);
                list.Add(el);

            }
            return list;

        }
        private JefeDTO convert(Jefe item)
        {
            JefeDTO obj = new JefeDTO(item.rut_jefe, item.nombre_jefe, item.apellido_jefe);
            return obj;

        }
    }

}