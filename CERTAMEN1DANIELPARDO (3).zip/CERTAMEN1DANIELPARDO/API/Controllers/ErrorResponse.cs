﻿namespace API.Controllers
{
    internal class ErrorResponse
    {
        private Exception ex;

        public ErrorResponse(Exception ex)
        {
            this.ex = ex;
        }
    }
}