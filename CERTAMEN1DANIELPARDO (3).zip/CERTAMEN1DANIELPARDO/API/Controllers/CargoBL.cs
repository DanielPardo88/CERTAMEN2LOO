﻿namespace API.Controllers
{
    internal class CargoBL
    {
        public CargoBL()
        {
        }

        internal object? Delete(Cargo cargo)
        {
            throw new NotImplementedException();
        }

        internal Cargo GetById(Cargo cargo)
        {
            throw new NotImplementedException();
        }

        internal List<Cargo> GetQuery(Cargo cargo)
        {
            throw new NotImplementedException();
        }

        internal object? Update(Cargo cargo)
        {
            throw new NotImplementedException();
        }
    }
}