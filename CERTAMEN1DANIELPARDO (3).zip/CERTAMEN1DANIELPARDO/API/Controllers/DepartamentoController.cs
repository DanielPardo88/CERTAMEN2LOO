﻿using System;
using System.Reflection;
using API.Helper;
using Microsoft.AspNetCore.Mvc;
using Modelos.Mantenedores;
using Negocio.Mantenedores;
using static API.Datos;

namespace API.Controllers
{
    [ApiController]

    public class DepartamentoController : ControllerBase
    {
        DepartamentoBL departamentoBL = new DepartamentoBL();
        Departamento departamento = new Departamento();
        ErrorResponse error;

        public DepartamentoBL DepartamentoBL { get => DepartamentoBL1; set => DepartamentoBL1 = value; }
        public DepartamentoBL DepartamentoBL1 { get => departamentoBL; set => departamentoBL = value; }

        [HttpPost]
        [Route("v1/departamento/Create")]
        public ActionResult Create(DepartamentoDTO o)
        {
            try
            {
                departamento.id_departamento = o.id_departamento;
                departamento.nombre_departamento = o.nombre_departamento;
                return Ok(DepartamentoBL.Create(departamento));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/departamento/Get")]
        public ActionResult Get()
        {
            try
            {
                return Ok(convertList(DepartamentoBL.Get(departamento)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpPost]
        [Route("v1/departamento/GetQuery")]
        public ActionResult GetQuery(string nombre)
        {
            try
            {
                departamento.nombre_departamento = nombre;
                return Ok(convertList(DepartamentoBL.GetQuery(departamento)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/departamento/GetById")]
        public ActionResult GetById(int id)
        {
            try
            {
                departamento.id_departamento = id;
                departamento = DepartamentoBL.GetById(departamento);
                if (departamento != null)
                    return Ok(convert(departamento));
                else
                    return StatusCode(404, departamento);
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }
        [HttpPut]
        [Route("v1/departamento/Update")]
        public ActionResult Update(DepartamentoDTO o)
        {
            try
            {
                departamento.id_departamento = o.id_departamento;
                departamento.nombre_departamento = o.nombre_departamento;
                return Ok(DepartamentoBL.Update(departamento));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpDelete]
        [Route("v1/departamento/Delete")]
        public ActionResult Delete(int id)
        {
            try
            {
                departamento.id_departamento = id;
                return Ok(DepartamentoBL.Delete(departamento));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        private List<DepartamentoDTO> convertList(List<Departamento> lista)
        {
            List<DepartamentoDTO> list = new List<DepartamentoDTO>();
            foreach (var item in lista)
            {
                DepartamentoDTO el = new DepartamentoDTO(item.id_departamento, item.nombre_departamento);
                list.Add(el);

            }
            return list;

        }
        private DepartamentoDTO convert(Departamento item)
        {
            DepartamentoDTO obj = new DepartamentoDTO(item.id_departamento, item.nombre_departamento);
            return obj;

        }
    }

}