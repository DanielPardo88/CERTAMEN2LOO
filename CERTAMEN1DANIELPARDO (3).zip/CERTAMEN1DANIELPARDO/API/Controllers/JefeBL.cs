﻿namespace API.Controllers
{
    internal class JefeBL
    {
        internal int rut_jefe;
        internal string nombre_jefe;
        internal string apellido_jefe;

        public JefeBL()
        {
        }
    }
}