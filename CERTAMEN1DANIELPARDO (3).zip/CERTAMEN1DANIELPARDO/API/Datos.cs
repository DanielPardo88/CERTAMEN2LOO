﻿namespace API
{
    public class Datos
    {
        public record CargoDTO(int id_cargo, string nombre_cargo);
        public record DepartamentoDTO(int id_departamento, string nombre_departamento);
        public record EmpleadosDTO(int rut_empleado, string nombre_empleado, string apellido_empleado, string direccion, int telefono);
        public record JefeDTO(int rut_jefe, string nombre_jefe, string apellido_jefe);
        public record RegionDTO(int id_region, string nombre_region);
        public record SucursalesDTO(int id_sucursal, string ciudad, string direccion, int telefono);
    }
}
